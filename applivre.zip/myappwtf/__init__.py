from .app import app,db
import myappwtf.views
import myappwtf.models
import myappwtf.commands
