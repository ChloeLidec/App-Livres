pip install flask
pip install python-dotenv
pip install pyyaml
pip install bootstrap-flask
pip install flask-sqlalchemy
pip install flask-wtf
pip install flask-login
